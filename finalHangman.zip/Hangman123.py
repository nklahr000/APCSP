import time 
import random

print "Hangman time!"
time.sleep(1)
words = ["square", "science", "bus", "pancake"]
word = random.choice(words)
guesses = ''
turns = 10
while turns > 0:
    failed = 0
    for w in word:
        if w in guesses:
            print w,
        else:
            print "_"
            failed += 1
    if failed == 0:
        print "You won!"
        break
    print
    guess = raw_input("Guess a letter:")
    guesses += guess
    if guess not in word:
        turns -= 1
        print "Incorrect"
        print "You have", + turns, 'more guesses'
        if turns == 0:
            print "You lose!"
    